package gui;

import javax.swing.*;
import java.awt.event.*;
import java.util.List;

import model.*;
import service.TransactionManager;

public class DashboardPanel extends JPanel {
    public DashboardPanel(User user, TransactionManager txManager, BankGUI parent) {
        setLayout(null);

        JLabel welcome = new JLabel("Welcome, " + user.getUsername());
        welcome.setBounds(20, 10, 250, 30);
        add(welcome);

        Account acc = user.getAccount();

        JLabel accInfo = new JLabel("Account: " + acc.getAccountNumber() + " (" + acc.getAccountType() + ")");
        accInfo.setBounds(20, 40, 300, 25);
        add(accInfo);

        JLabel balLabel = new JLabel("Balance: ₹" + acc.getBalance());
        balLabel.setBounds(20, 70, 200, 25);
        add(balLabel);

        JTextField amountField = new JTextField();
        amountField.setBounds(20, 110, 150, 25);
        add(amountField);

        JButton depositBtn = new JButton("Deposit");
        depositBtn.setBounds(180, 110, 100, 25);
        add(depositBtn);

        JButton withdrawBtn = new JButton("Withdraw");
        withdrawBtn.setBounds(290, 110, 100, 25);
        add(withdrawBtn);

        JTextArea txLog = new JTextArea();
        txLog.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(txLog);
        scrollPane.setBounds(20, 150, 450, 180);
        add(scrollPane);

        depositBtn.addActionListener(e -> {
            double amt = Double.parseDouble(amountField.getText());
            acc.deposit(amt);
            txManager.record(acc.getAccountNumber(), new Transaction("Deposit", amt));
            balLabel.setText("Balance: ₹" + acc.getBalance());
            refreshLogs(txManager.getTransactions(acc.getAccountNumber()), txLog);
        });

        withdrawBtn.addActionListener(e -> {
            double amt = Double.parseDouble(amountField.getText());
            if (acc.withdraw(amt)) {
                txManager.record(acc.getAccountNumber(), new Transaction("Withdraw", amt));
                balLabel.setText("Balance: ₹" + acc.getBalance());
                refreshLogs(txManager.getTransactions(acc.getAccountNumber()), txLog);
            } else {
                JOptionPane.showMessageDialog(null, "Insufficient Balance");
            }
        });

        refreshLogs(txManager.getTransactions(acc.getAccountNumber()), txLog);
    }

    private void refreshLogs(List<Transaction> txs, JTextArea txLog) {
        txLog.setText("");
        for (Transaction tx : txs) {
            txLog.append(tx.toString() + "\n");
        }
    }
}
