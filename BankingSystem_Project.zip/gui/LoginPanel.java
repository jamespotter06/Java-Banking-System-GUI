package gui;

import javax.swing.*;
import service.BankSystem;
import service.TransactionManager;

import java.awt.*;
import java.awt.event.*;

public class LoginPanel extends JPanel {
    public LoginPanel(BankGUI parent, BankSystem bankSystem, TransactionManager txManager) {
        setLayout(null);

        JLabel title = new JLabel("Login/Register");
        title.setBounds(180, 20, 150, 30);
        add(title);

        JLabel userLbl = new JLabel("Username:");
        userLbl.setBounds(100, 70, 100, 25);
        add(userLbl);

        JTextField username = new JTextField();
        username.setBounds(200, 70, 150, 25);
        add(username);

        JLabel passLbl = new JLabel("Password:");
        passLbl.setBounds(100, 110, 100, 25);
        add(passLbl);

        JPasswordField password = new JPasswordField();
        password.setBounds(200, 110, 150, 25);
        add(password);

        JComboBox<String> typeBox = new JComboBox<>(new String[]{"Savings", "Current"});
        typeBox.setBounds(200, 150, 150, 25);
        add(typeBox);

        JButton loginBtn = new JButton("Login");
        loginBtn.setBounds(100, 200, 100, 30);
        add(loginBtn);

        JButton regBtn = new JButton("Register");
        regBtn.setBounds(250, 200, 100, 30);
        add(regBtn);

        loginBtn.addActionListener(e -> {
            var user = bankSystem.loginUser(username.getText(), new String(password.getPassword()));
            if (user != null) parent.switchToDashboard(user);
            else JOptionPane.showMessageDialog(null, "Invalid credentials!");
        });

        regBtn.addActionListener(e -> {
            boolean success = bankSystem.registerUser(username.getText(), new String(password.getPassword()), (String) typeBox.getSelectedItem());
            if (success) JOptionPane.showMessageDialog(null, "Registered successfully!");
            else JOptionPane.showMessageDialog(null, "User already exists!");
        });
    }
}
