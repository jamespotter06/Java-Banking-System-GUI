package gui;

import javax.swing.*;
import service.BankSystem;
import service.TransactionManager;

public class BankGUI extends JFrame {
    private BankSystem bankSystem;
    private TransactionManager txManager;

    public BankGUI() {
        super("Banking System");

        bankSystem = new BankSystem();
        txManager = new TransactionManager();

        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        setContentPane(new LoginPanel(this, bankSystem, txManager));
        setVisible(true);
    }

    public void switchToDashboard(model.User user) {
        setContentPane(new DashboardPanel(user, txManager, this));
        revalidate();
    }
}
