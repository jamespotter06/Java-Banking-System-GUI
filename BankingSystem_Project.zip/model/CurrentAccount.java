package model;

public class CurrentAccount extends Account {
    public CurrentAccount(String accountNumber) {
        super(accountNumber);
    }

    @Override
    public String getAccountType() {
        return "Current";
    }
}
