package service;

import model.*;

import java.util.ArrayList;
import java.util.HashMap;

public class TransactionManager {
    private HashMap<String, ArrayList<Transaction>> logs = new HashMap<>();

    public void record(String accountNumber, Transaction tx) {
        logs.computeIfAbsent(accountNumber, k -> new ArrayList<>()).add(tx);
    }

    public ArrayList<Transaction> getTransactions(String accountNumber) {
        return logs.getOrDefault(accountNumber, new ArrayList<>());
    }
}
