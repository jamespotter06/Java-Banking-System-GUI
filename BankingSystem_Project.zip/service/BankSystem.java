package service;

import model.*;

import java.util.HashMap;

public class BankSystem {
    private HashMap<String, User> users = new HashMap<>();

    public boolean registerUser(String username, String password, String type) {
        if (users.containsKey(username)) return false;
        Account acc = type.equals("Savings") ? new SavingsAccount("AC" + (users.size()+1)) : new CurrentAccount("AC" + (users.size()+1));
        users.put(username, new User(username, password, acc));
        return true;
    }

    public User loginUser(String username, String password) {
        User user = users.get(username);
        return (user != null && user.checkPassword(password)) ? user : null;
    }
}
